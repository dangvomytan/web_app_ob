function Forbidden() {
  return (
    <>
      <div>Forbidden</div>
    </>
  );
}

export default Forbidden;
