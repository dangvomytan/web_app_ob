function ResourceNotFound() {
  return (
    <>
      <div>ResourceNotFound</div>
    </>
  );
}

export default ResourceNotFound;
