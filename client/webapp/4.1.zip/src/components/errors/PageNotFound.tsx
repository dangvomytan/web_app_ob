function PageNotFound() {
  return (
    <>
      <div>PageNotFound</div>
    </>
  );
}

export default PageNotFound;
