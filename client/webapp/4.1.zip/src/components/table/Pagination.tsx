function Pagination() {
  return (
    <>
      <div>Pagination</div>
    </>
  );
}

export default Pagination;
