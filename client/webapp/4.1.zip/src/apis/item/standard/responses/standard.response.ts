export interface StandarResponse {}
